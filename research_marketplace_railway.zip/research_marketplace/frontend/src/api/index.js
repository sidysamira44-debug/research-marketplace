// ── Auth API ──────────────────────────────────────────────────────────────
import api from './axios'

export const authAPI = {
  register: (data)         => api.post('/auth/register/', data),
  login:    (data)         => api.post('/auth/login/', data),
  logout:   (refresh)      => api.post('/auth/logout/', { refresh }),
  me:       ()             => api.get('/auth/me/'),
  updateMe: (data)         => api.patch('/auth/me/', data),
  changePassword: (data)   => api.post('/auth/change-password/', data),
  verifyUser: (userId)     => api.post(`/auth/verify/${userId}/`),
  listUsers: (params)      => api.get('/auth/users/', { params }),
}

// ── Profiles API ──────────────────────────────────────────────────────────
export const profilesAPI = {
  skills:          (params) => api.get('/profiles/skills/', { params }),
  myStudent:       ()       => api.get('/profiles/me/student/'),
  updateStudent:   (data)   => api.patch('/profiles/me/student/', data),
  myEmployer:      ()       => api.get('/profiles/me/employer/'),
  updateEmployer:  (data)   => api.patch('/profiles/me/employer/', data),
  students:        (params) => api.get('/profiles/students/', { params }),
  studentDetail:   (id)     => api.get(`/profiles/students/${id}/`),
  employerDetail:  (id)     => api.get(`/profiles/employers/${id}/`),
}

// ── Projects API ──────────────────────────────────────────────────────────
export const projectsAPI = {
  list:       (params)  => api.get('/projects/', { params }),
  categories: ()        => api.get('/projects/categories/'),
  myProjects: (params)  => api.get('/projects/my/', { params }),
  create:     (data)    => api.post('/projects/', data),
  detail:     (id)      => api.get(`/projects/${id}/`),
  update:     (id, data)=> api.patch(`/projects/${id}/`, data),
  cancel:     (id)      => api.delete(`/projects/${id}/`),
  publish:    (id)      => api.post(`/projects/${id}/publish/`),
  complete:   (id)      => api.post(`/projects/${id}/complete/`),
  addReview:  (projectId, data) => api.post(`/projects/${projectId}/review/`, data),
}

// ── Proposals API ─────────────────────────────────────────────────────────
export const proposalsAPI = {
  submit:          (data)       => api.post('/proposals/', data),
  myProposals:     (params)     => api.get('/proposals/my/', { params }),
  projectProposals:(projectId, params) => api.get(`/proposals/project/${projectId}/`, { params }),
  detail:          (id)         => api.get(`/proposals/${id}/`),
  action:          (id, data)   => api.post(`/proposals/${id}/action/`, data),
  withdraw:        (id)         => api.post(`/proposals/${id}/withdraw/`),
  getMessages:     (projectId)  => api.get(`/proposals/messages/${projectId}/`),
  sendMessage:     (projectId, data) => api.post(`/proposals/messages/${projectId}/`, data),
}

// ── Payments API ──────────────────────────────────────────────────────────
export const paymentsAPI = {
  createIntent:   (data)  => api.post('/payments/create-intent/', data),
  transactions:   (params)=> api.get('/payments/transactions/', { params }),
  raiseDispute:   (data)  => api.post('/payments/dispute/', data),
  disputes:       (params)=> api.get('/payments/disputes/', { params }),
  resolveDispute: (id, data) => api.post(`/payments/disputes/${id}/resolve/`, data),
  releaseEscrow:  (txnId) => api.post(`/payments/release/${txnId}/`),
}

// ── Notifications API ─────────────────────────────────────────────────────
export const notificationsAPI = {
  list:         (params) => api.get('/notifications/', { params }),
  unreadCount:  ()       => api.get('/notifications/unread-count/'),
  markRead:     (id)     => api.post(`/notifications/${id}/read/`),
  markAllRead:  ()       => api.post('/notifications/read-all/'),
}
