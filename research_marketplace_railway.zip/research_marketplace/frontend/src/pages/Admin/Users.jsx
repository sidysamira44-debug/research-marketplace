import { useState } from 'react'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { FiCheck, FiSearch } from 'react-icons/fi'
import { authAPI } from '../../api'
import { Spinner } from '../../components/common'
import toast from 'react-hot-toast'

const ROLE_CLS = { student:'badge-blue', employer:'badge-green', admin:'badge-red' }
const ROLE_LBL = { student:'دانشجو', employer:'کارفرما', admin:'مدیر' }

export default function AdminUsers() {
  const qc = useQueryClient()
  const [search, setSearch] = useState('')
  const [roleFilter, setRoleFilter] = useState('')

  const { data, isLoading } = useQuery({
    queryKey: ['admin-users', search, roleFilter],
    queryFn: () => authAPI.listUsers({ search, role: roleFilter, page_size: 50 }).then(r => r.data),
  })

  const verify = useMutation({
    mutationFn: (id) => authAPI.verifyUser(id),
    onSuccess: () => { toast.success('کاربر تأیید شد'); qc.invalidateQueries(['admin-users']) },
    onError: (err) => toast.error(err.response?.data?.error?.message || 'خطا'),
  })

  return (
    <div className="space-y-5">
      <h1 className="page-title">مدیریت کاربران</h1>

      <div className="card p-4 flex gap-3">
        <div className="relative flex-1">
          <FiSearch className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400" size={16} />
          <input value={search} onChange={e => setSearch(e.target.value)} placeholder="جستجوی نام یا ایمیل..." className="input pr-9" />
        </div>
        <select value={roleFilter} onChange={e => setRoleFilter(e.target.value)} className="input w-36">
          <option value="">همه نقش‌ها</option>
          <option value="student">دانشجو</option>
          <option value="employer">کارفرما</option>
        </select>
      </div>

      {isLoading ? <Spinner /> : (
        <div className="card overflow-hidden">
          <table className="w-full text-sm">
            <thead className="bg-gray-50 border-b border-gray-200">
              <tr>
                <th className="text-right px-4 py-3 font-medium text-gray-600">نام</th>
                <th className="text-right px-4 py-3 font-medium text-gray-600">ایمیل</th>
                <th className="text-right px-4 py-3 font-medium text-gray-600">نقش</th>
                <th className="text-right px-4 py-3 font-medium text-gray-600">وضعیت</th>
                <th className="px-4 py-3"></th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {data?.results?.map(u => (
                <tr key={u.id} className="hover:bg-gray-50 transition-colors">
                  <td className="px-4 py-3 font-medium text-gray-900">{u.full_name}</td>
                  <td className="px-4 py-3 text-gray-500 font-mono text-xs" dir="ltr">{u.email}</td>
                  <td className="px-4 py-3"><span className={ROLE_CLS[u.role]}>{ROLE_LBL[u.role]}</span></td>
                  <td className="px-4 py-3">
                    {u.is_verified
                      ? <span className="badge-green">✓ تأیید شده</span>
                      : <span className="badge-yellow">⏳ در انتظار</span>
                    }
                  </td>
                  <td className="px-4 py-3">
                    {!u.is_verified && (
                      <button
                        onClick={() => verify.mutate(u.id)}
                        disabled={verify.isPending}
                        className="btn-primary text-xs py-1 px-3 gap-1"
                      >
                        <FiCheck size={12} /> تأیید
                      </button>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  )
}
