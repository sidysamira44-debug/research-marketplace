// ── Admin Dashboard ────────────────────────────────────────────────────────
import { useQuery } from '@tanstack/react-query'
import { FiUsers, FiAlertTriangle } from 'react-icons/fi'
import { authAPI, paymentsAPI } from '../../api'
import StatCard from '../../components/common/StatCard'
import { Spinner } from '../../components/common'

export default function AdminDashboard() {
  const { data: users } = useQuery({
    queryKey: ['admin-users'],
    queryFn: () => authAPI.listUsers({ page_size: 100 }).then(r => r.data),
  })
  const { data: disputes } = useQuery({
    queryKey: ['disputes'],
    queryFn: () => paymentsAPI.disputes().then(r => r.data),
  })

  const unverified = users?.results?.filter(u => !u.is_verified).length || 0
  const pending = disputes?.results?.filter(d => d.resolution === 'pending').length || 0

  return (
    <div className="space-y-6">
      <h1 className="page-title">داشبورد مدیریت</h1>
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard icon={FiUsers} label="کل کاربران"    value={users?.count}  color="blue" />
        <StatCard icon={FiUsers} label="منتظر تأیید"   value={unverified}    color="yellow" />
        <StatCard icon={FiAlertTriangle} label="اختلافات"  value={disputes?.count} color="red" />
        <StatCard icon={FiAlertTriangle} label="در انتظار بررسی" value={pending} color="purple" />
      </div>

      {unverified > 0 && (
        <div className="bg-yellow-50 border border-yellow-200 rounded-xl p-4">
          <p className="font-medium text-yellow-800">⚠️ {unverified} کاربر منتظر تأیید هستند</p>
          <p className="text-sm text-yellow-600 mt-1">به بخش کاربران رفته و آن‌ها را تأیید کنید.</p>
        </div>
      )}
    </div>
  )
}
