import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { paymentsAPI } from '../../api'
import { Spinner, Empty } from '../../components/common'
import toast from 'react-hot-toast'

export default function AdminDisputes() {
  const qc = useQueryClient()
  const { data, isLoading } = useQuery({
    queryKey: ['disputes'],
    queryFn: () => paymentsAPI.disputes().then(r => r.data.results || []),
  })

  const resolve = useMutation({
    mutationFn: ({ id, resolution }) => paymentsAPI.resolveDispute(id, { resolution }),
    onSuccess: () => { toast.success('اختلاف حل شد'); qc.invalidateQueries(['disputes']) },
    onError: (err) => toast.error(err.response?.data?.error?.message || 'خطا'),
  })

  if (isLoading) return <Spinner />

  return (
    <div className="space-y-5">
      <h1 className="page-title">مدیریت اختلافات</h1>
      {!data?.length ? <Empty message="هیچ اختلافی ثبت نشده" icon="⚖️" /> : (
        <div className="space-y-4">
          {data.map(d => (
            <div key={d.id} className="card p-5">
              <div className="flex items-start justify-between gap-4 mb-3">
                <div>
                  <p className="font-semibold text-gray-900">پروژه: {d.project}</p>
                  <p className="text-xs text-gray-500">توسط: {d.raised_by?.full_name} · {new Date(d.created_at).toLocaleDateString('fa-IR')}</p>
                </div>
                <span className={d.resolution === 'pending' ? 'badge-yellow' : 'badge-green'}>
                  {d.resolution === 'pending' ? 'در انتظار' : 'حل شده'}
                </span>
              </div>
              <p className="text-sm text-gray-600 mb-4">{d.reason}</p>
              {d.resolution === 'pending' && (
                <div className="flex gap-2">
                  <button onClick={() => resolve.mutate({ id: d.id, resolution: 'resolved_for_employer' })} className="btn-secondary text-xs py-1.5">به نفع کارفرما</button>
                  <button onClick={() => resolve.mutate({ id: d.id, resolution: 'resolved_for_student' })} className="btn-secondary text-xs py-1.5">به نفع دانشجو</button>
                  <button onClick={() => resolve.mutate({ id: d.id, resolution: 'split' })} className="btn-secondary text-xs py-1.5">تقسیم وجه</button>
                </div>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  )
}
