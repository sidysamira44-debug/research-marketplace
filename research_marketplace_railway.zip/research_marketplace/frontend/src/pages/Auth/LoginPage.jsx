import { useState } from 'react'
import { Link, useNavigate, useLocation } from 'react-router-dom'
import { useForm } from 'react-hook-form'
import { FiMail, FiLock, FiEye, FiEyeOff } from 'react-icons/fi'
import useAuthStore from '../../store/authStore'
import toast from 'react-hot-toast'

const ROLE_HOME = { student: '/student', employer: '/employer', admin: '/admin' }

export default function LoginPage() {
  const [showPassword, setShowPassword] = useState(false)
  const [loading, setLoading] = useState(false)
  const { login } = useAuthStore()
  const navigate = useNavigate()
  const location = useLocation()

  const { register, handleSubmit, formState: { errors } } = useForm()

  const onSubmit = async ({ email, password }) => {
    setLoading(true)
    try {
      const user = await login(email, password)
      toast.success(`خوش آمدید، ${user.full_name}!`)
      const from = location.state?.from?.pathname || ROLE_HOME[user.role] || '/student'
      navigate(from, { replace: true })
    } catch (err) {
      const msg = err.response?.data?.error?.message || 'خطا در ورود. دوباره تلاش کنید.'
      toast.error(msg)
    } finally {
      setLoading(false)
    }
  }

  return (
    <div>
      <h2 className="text-xl font-bold text-gray-900 mb-6">ورود به حساب</h2>

      <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
        {/* Email */}
        <div>
          <label className="label">ایمیل</label>
          <div className="relative">
            <FiMail className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400" size={16} />
            <input
              {...register('email', {
                required: 'ایمیل الزامی است',
                pattern: { value: /\S+@\S+\.\S+/, message: 'ایمیل نامعتبر است' },
              })}
              type="email"
              placeholder="example@email.com"
              className={`input pr-9 ${errors.email ? 'input-error' : ''}`}
              dir="ltr"
            />
          </div>
          {errors.email && <p className="text-xs text-danger-500 mt-1">{errors.email.message}</p>}
        </div>

        {/* Password */}
        <div>
          <label className="label">رمز عبور</label>
          <div className="relative">
            <FiLock className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400" size={16} />
            <input
              {...register('password', { required: 'رمز عبور الزامی است' })}
              type={showPassword ? 'text' : 'password'}
              placeholder="رمز عبور"
              className={`input pr-9 pl-9 ${errors.password ? 'input-error' : ''}`}
              dir="ltr"
            />
            <button
              type="button"
              onClick={() => setShowPassword(v => !v)}
              className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600"
            >
              {showPassword ? <FiEyeOff size={16} /> : <FiEye size={16} />}
            </button>
          </div>
          {errors.password && <p className="text-xs text-danger-500 mt-1">{errors.password.message}</p>}
        </div>

        <button type="submit" disabled={loading} className="btn-primary w-full py-2.5">
          {loading ? (
            <span className="flex items-center gap-2 justify-center">
              <svg className="animate-spin h-4 w-4" viewBox="0 0 24 24" fill="none">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"/>
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8z"/>
              </svg>
              در حال ورود...
            </span>
          ) : 'ورود'}
        </button>
      </form>

      <p className="text-center text-sm text-gray-500 mt-6">
        حساب ندارید؟{' '}
        <Link to="/register" className="text-primary-600 font-medium hover:underline">
          ثبت‌نام کنید
        </Link>
      </p>
    </div>
  )
}
