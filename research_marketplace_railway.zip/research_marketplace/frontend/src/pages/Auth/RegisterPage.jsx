import { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { useForm } from 'react-hook-form'
import { FiUser, FiMail, FiLock, FiPhone } from 'react-icons/fi'
import { authAPI } from '../../api'
import useAuthStore from '../../store/authStore'
import toast from 'react-hot-toast'

const ROLE_HOME = { student: '/student', employer: '/employer' }

export default function RegisterPage() {
  const [loading, setLoading] = useState(false)
  const { setTokens, setUser } = useAuthStore()
  const navigate = useNavigate()
  const { register, handleSubmit, watch, formState: { errors } } = useForm({
    defaultValues: { role: 'student' },
  })

  const password = watch('password')

  const onSubmit = async (values) => {
    setLoading(true)
    try {
      const { data } = await authAPI.register(values)
      setTokens(data.data.tokens.access, data.data.tokens.refresh)
      setUser(data.data)
      toast.success('ثبت‌نام با موفقیت انجام شد!')
      navigate(ROLE_HOME[data.data.role] || '/student')
    } catch (err) {
      const detail = err.response?.data?.error?.details
      if (detail) {
        const firstError = Object.values(detail)[0]
        toast.error(Array.isArray(firstError) ? firstError[0] : firstError)
      } else {
        toast.error(err.response?.data?.error?.message || 'خطا در ثبت‌نام')
      }
    } finally {
      setLoading(false)
    }
  }

  return (
    <div>
      <h2 className="text-xl font-bold text-gray-900 mb-6">ایجاد حساب جدید</h2>

      <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
        {/* Role selector */}
        <div>
          <label className="label">نقش شما</label>
          <div className="grid grid-cols-2 gap-3">
            {[
              { value: 'student',  label: '🎓 دانشجو',  desc: 'ارسال پیشنهاد و کسب درآمد' },
              { value: 'employer', label: '🏢 کارفرما', desc: 'پست پروژه و استخدام' },
            ].map(({ value, label, desc }) => (
              <label
                key={value}
                className={`relative cursor-pointer rounded-lg border-2 p-3 transition-all ${
                  watch('role') === value
                    ? 'border-primary-500 bg-primary-50'
                    : 'border-gray-200 hover:border-gray-300'
                }`}
              >
                <input {...register('role')} type="radio" value={value} className="sr-only" />
                <p className="text-sm font-medium text-gray-900">{label}</p>
                <p className="text-xs text-gray-500">{desc}</p>
              </label>
            ))}
          </div>
        </div>

        {/* Full Name */}
        <div>
          <label className="label">نام و نام خانوادگی</label>
          <div className="relative">
            <FiUser className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400" size={16} />
            <input
              {...register('full_name', { required: 'نام الزامی است', minLength: { value: 3, message: 'حداقل ۳ کاراکتر' } })}
              placeholder="علی احمدی"
              className={`input pr-9 ${errors.full_name ? 'input-error' : ''}`}
            />
          </div>
          {errors.full_name && <p className="text-xs text-danger-500 mt-1">{errors.full_name.message}</p>}
        </div>

        {/* Email */}
        <div>
          <label className="label">ایمیل</label>
          <div className="relative">
            <FiMail className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400" size={16} />
            <input
              {...register('email', {
                required: 'ایمیل الزامی است',
                pattern: { value: /\S+@\S+\.\S+/, message: 'ایمیل نامعتبر است' },
              })}
              type="email"
              placeholder="example@email.com"
              className={`input pr-9 ${errors.email ? 'input-error' : ''}`}
              dir="ltr"
            />
          </div>
          {errors.email && <p className="text-xs text-danger-500 mt-1">{errors.email.message}</p>}
        </div>

        {/* Phone */}
        <div>
          <label className="label">شماره تماس <span className="text-gray-400">(اختیاری)</span></label>
          <div className="relative">
            <FiPhone className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400" size={16} />
            <input
              {...register('phone_number')}
              placeholder="09xxxxxxxxx"
              className="input pr-9"
              dir="ltr"
            />
          </div>
        </div>

        {/* Password */}
        <div>
          <label className="label">رمز عبور</label>
          <div className="relative">
            <FiLock className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400" size={16} />
            <input
              {...register('password', {
                required: 'رمز عبور الزامی است',
                minLength: { value: 8, message: 'حداقل ۸ کاراکتر' },
              })}
              type="password"
              placeholder="حداقل ۸ کاراکتر"
              className={`input pr-9 ${errors.password ? 'input-error' : ''}`}
              dir="ltr"
            />
          </div>
          {errors.password && <p className="text-xs text-danger-500 mt-1">{errors.password.message}</p>}
        </div>

        {/* Confirm Password */}
        <div>
          <label className="label">تکرار رمز عبور</label>
          <div className="relative">
            <FiLock className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400" size={16} />
            <input
              {...register('password2', {
                required: 'تکرار رمز الزامی است',
                validate: v => v === password || 'رمزها یکسان نیستند',
              })}
              type="password"
              placeholder="تکرار رمز عبور"
              className={`input pr-9 ${errors.password2 ? 'input-error' : ''}`}
              dir="ltr"
            />
          </div>
          {errors.password2 && <p className="text-xs text-danger-500 mt-1">{errors.password2.message}</p>}
        </div>

        <button type="submit" disabled={loading} className="btn-primary w-full py-2.5">
          {loading ? 'در حال ثبت‌نام...' : 'ثبت‌نام'}
        </button>
      </form>

      <p className="text-center text-sm text-gray-500 mt-6">
        حساب دارید؟{' '}
        <Link to="/login" className="text-primary-600 font-medium hover:underline">وارد شوید</Link>
      </p>
    </div>
  )
}
