// ── MyProjects ────────────────────────────────────────────────────────────
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { Link } from 'react-router-dom'
import { projectsAPI } from '../../api'
import { Spinner, Empty } from '../../components/common'
import toast from 'react-hot-toast'

const S_CLS = { draft:'badge-gray',open:'badge-green',in_progress:'badge-blue',completed:'badge-purple',cancelled:'badge-red',disputed:'badge-yellow' }
const S_LBL = { draft:'پیش‌نویس',open:'باز',in_progress:'در حال انجام',completed:'تکمیل',cancelled:'لغو',disputed:'اختلاف' }

export default function MyProjects() {
  const qc = useQueryClient()
  const { data, isLoading } = useQuery({
    queryKey: ['my-projects'],
    queryFn: () => projectsAPI.myProjects({ page_size: 50 }).then(r => r.data),
  })

  const publish = useMutation({
    mutationFn: (id) => projectsAPI.publish(id),
    onSuccess: () => { toast.success('پروژه منتشر شد'); qc.invalidateQueries(['my-projects']) },
    onError: (err) => toast.error(err.response?.data?.error?.message || 'خطا'),
  })

  if (isLoading) return <Spinner />
  const projects = data?.results || []

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between">
        <h1 className="page-title">پروژه‌های من</h1>
        <Link to="/employer/projects/create" className="btn-primary text-sm">+ پروژه جدید</Link>
      </div>
      {!projects.length ? <Empty message="هنوز پروژه‌ای ندارید" icon="📂" /> : (
        <div className="space-y-3">
          {projects.map(p => (
            <div key={p.id} className="card p-5 flex items-center gap-4">
              <div className="flex-1 min-w-0">
                <p className="font-semibold text-gray-900 truncate">{p.title}</p>
                <p className="text-xs text-gray-500 mt-0.5">{p.budget_display} · {p.proposals_count} پیشنهاد</p>
              </div>
              <span className={S_CLS[p.status]}>{S_LBL[p.status]}</span>
              <div className="flex gap-2">
                {p.status === 'draft' && (
                  <button onClick={() => publish.mutate(p.id)} disabled={publish.isPending} className="btn-primary text-xs py-1.5 px-3">انتشار</button>
                )}
                {p.status === 'open' && (
                  <Link to={`/employer/projects/${p.id}/proposals`} className="btn-secondary text-xs py-1.5 px-3">پیشنهادها ({p.proposals_count})</Link>
                )}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}
