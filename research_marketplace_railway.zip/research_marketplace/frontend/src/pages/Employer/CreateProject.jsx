import { useNavigate } from 'react-router-dom'
import { useForm } from 'react-hook-form'
import { useMutation, useQuery } from '@tanstack/react-query'
import { projectsAPI, profilesAPI } from '../../api'
import toast from 'react-hot-toast'

export default function CreateProject() {
  const navigate = useNavigate()
  const { register, handleSubmit, formState: { errors } } = useForm()

  const { data: categories } = useQuery({
    queryKey: ['categories'],
    queryFn: () => projectsAPI.categories().then(r => r.data),
  })
  const { data: skills } = useQuery({
    queryKey: ['skills'],
    queryFn: () => profilesAPI.skills().then(r => r.data),
  })

  const create = useMutation({
    mutationFn: (data) => projectsAPI.create(data),
    onSuccess: (res) => {
      toast.success('پروژه ایجاد شد!')
      navigate('/employer/projects')
    },
    onError: (err) => toast.error(err.response?.data?.error?.message || 'خطا در ایجاد پروژه'),
  })

  const onSubmit = (values) => {
    const payload = {
      ...values,
      budget_min: Number(values.budget_min),
      budget_max: Number(values.budget_max),
      duration_days: Number(values.duration_days),
      required_skill_ids: values.required_skill_ids || [],
    }
    create.mutate(payload)
  }

  return (
    <div className="max-w-2xl space-y-6">
      <h1 className="page-title">پروژه جدید</h1>

      <form onSubmit={handleSubmit(onSubmit)} className="card p-6 space-y-5">
        <div>
          <label className="label">عنوان پروژه *</label>
          <input {...register('title', { required: 'الزامی' })} className={`input ${errors.title ? 'input-error' : ''}`} placeholder="عنوان واضح و توصیفی" />
          {errors.title && <p className="text-xs text-danger-500 mt-1">{errors.title.message}</p>}
        </div>

        <div>
          <label className="label">توضیحات کامل *</label>
          <textarea {...register('description', { required: 'الزامی', minLength: { value: 100, message: 'حداقل ۱۰۰ کاراکتر' } })}
            rows={5} className={`input resize-none ${errors.description ? 'input-error' : ''}`}
            placeholder="پروژه را به طور کامل شرح دهید..." />
          {errors.description && <p className="text-xs text-danger-500 mt-1">{errors.description.message}</p>}
        </div>

        <div>
          <label className="label">خروجی‌های مورد انتظار</label>
          <textarea {...register('deliverables')} rows={3} className="input resize-none" placeholder="چه چیزی تحویل می‌گیرید؟" />
        </div>

        <div className="grid sm:grid-cols-2 gap-4">
          <div>
            <label className="label">حداقل بودجه (تومان) *</label>
            <input {...register('budget_min', { required: 'الزامی', min: { value: 1, message: 'باید بیشتر از صفر باشد' } })}
              type="number" className={`input ${errors.budget_min ? 'input-error' : ''}`} dir="ltr" />
            {errors.budget_min && <p className="text-xs text-danger-500 mt-1">{errors.budget_min.message}</p>}
          </div>
          <div>
            <label className="label">حداکثر بودجه (تومان) *</label>
            <input {...register('budget_max', { required: 'الزامی' })}
              type="number" className={`input ${errors.budget_max ? 'input-error' : ''}`} dir="ltr" />
          </div>
          <div>
            <label className="label">مدت زمان (روز) *</label>
            <input {...register('duration_days', { required: 'الزامی', min: { value: 1 } })}
              type="number" className={`input ${errors.duration_days ? 'input-error' : ''}`} dir="ltr" />
          </div>
          <div>
            <label className="label">مهلت ارسال پیشنهاد</label>
            <input {...register('deadline')} type="date" className="input" dir="ltr" />
          </div>
        </div>

        <div className="grid sm:grid-cols-2 gap-4">
          <div>
            <label className="label">سطح تجربه</label>
            <select {...register('experience_level')} className="input">
              <option value="beginner">مبتدی</option>
              <option value="intermediate">متوسط</option>
              <option value="advanced">پیشرفته</option>
              <option value="expert">متخصص</option>
            </select>
          </div>
          <div>
            <label className="label">نوع پروژه</label>
            <select {...register('project_type')} className="input">
              <option value="one_time">یک بار</option>
              <option value="part_time">پاره وقت</option>
              <option value="full_time">تمام وقت</option>
              <option value="ongoing">مداوم</option>
            </select>
          </div>
        </div>

        {categories?.length > 0 && (
          <div>
            <label className="label">دسته‌بندی</label>
            <select {...register('category_id')} className="input">
              <option value="">بدون دسته‌بندی</option>
              {categories.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
            </select>
          </div>
        )}

        <div className="flex gap-3 pt-2">
          <button type="submit" name="publish" disabled={create.isPending} className="btn-primary flex-1 py-2.5">
            {create.isPending ? 'در حال ایجاد...' : 'ایجاد پروژه (پیش‌نویس)'}
          </button>
          <button type="button" onClick={() => navigate('/employer/projects')} className="btn-secondary">انصراف</button>
        </div>
      </form>
    </div>
  )
}
