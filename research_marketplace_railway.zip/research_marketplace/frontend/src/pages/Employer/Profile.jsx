import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { useForm } from 'react-hook-form'
import { useEffect } from 'react'
import { profilesAPI } from '../../api'
import { Spinner } from '../../components/common'
import toast from 'react-hot-toast'

export default function EmployerProfile() {
  const qc = useQueryClient()
  const { data: profile, isLoading } = useQuery({
    queryKey: ['my-employer-profile'],
    queryFn: () => profilesAPI.myEmployer().then(r => r.data.data),
  })

  const { register, handleSubmit, reset } = useForm()
  useEffect(() => { if (profile) reset(profile) }, [profile, reset])

  const update = useMutation({
    mutationFn: (data) => profilesAPI.updateEmployer(data),
    onSuccess: () => { toast.success('پروفایل به‌روزرسانی شد'); qc.invalidateQueries(['my-employer-profile']) },
    onError: () => toast.error('خطا در ذخیره'),
  })

  if (isLoading) return <Spinner />

  return (
    <div className="max-w-2xl space-y-6">
      <h1 className="page-title">پروفایل سازمان</h1>
      <form onSubmit={handleSubmit(d => update.mutate(d))} className="card p-6 space-y-4">
        <div>
          <label className="label">نام سازمان *</label>
          <input {...register('organization_name', { required: 'الزامی' })} className="input" />
        </div>
        <div className="grid sm:grid-cols-2 gap-4">
          <div>
            <label className="label">نوع سازمان</label>
            <select {...register('organization_type')} className="input">
              <option value="university">دانشگاه</option>
              <option value="research_center">مرکز تحقیقاتی</option>
              <option value="startup">استارتاپ</option>
              <option value="company">شرکت</option>
              <option value="ngo">سازمان غیرانتفاعی</option>
              <option value="government">دولتی</option>
            </select>
          </div>
          <div>
            <label className="label">وب‌سایت</label>
            <input {...register('website')} className="input" dir="ltr" placeholder="https://..." />
          </div>
          <div>
            <label className="label">شهر</label>
            <input {...register('city')} className="input" placeholder="تهران" />
          </div>
          <div>
            <label className="label">استان</label>
            <input {...register('province')} className="input" placeholder="تهران" />
          </div>
        </div>
        <div>
          <label className="label">توضیحات سازمان</label>
          <textarea {...register('description')} rows={4} className="input resize-none" placeholder="سازمان خود را معرفی کنید..." />
        </div>
        <button type="submit" disabled={update.isPending} className="btn-primary w-full py-2.5">
          {update.isPending ? 'در حال ذخیره...' : 'ذخیره تغییرات'}
        </button>
      </form>
    </div>
  )
}
