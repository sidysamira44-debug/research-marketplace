// ── Employer Dashboard ────────────────────────────────────────────────────
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { Link, useNavigate } from 'react-router-dom'
import { FiBriefcase, FiUsers, FiCheckCircle, FiPlusCircle } from 'react-icons/fi'
import { projectsAPI } from '../../api'
import StatCard from '../../components/common/StatCard'
import { Spinner } from '../../components/common'

const STATUS_CLS = {
  draft: 'badge-gray', open: 'badge-green', in_progress: 'badge-blue',
  completed: 'badge-purple', cancelled: 'badge-red', disputed: 'badge-yellow',
}
const STATUS_LBL = {
  draft: 'پیش‌نویس', open: 'باز', in_progress: 'در حال انجام',
  completed: 'تکمیل شده', cancelled: 'لغو شده', disputed: 'در اختلاف',
}

export function EmployerDashboard() {
  const navigate = useNavigate()
  const { data, isLoading } = useQuery({
    queryKey: ['my-projects'],
    queryFn: () => projectsAPI.myProjects({ page_size: 20 }).then(r => r.data),
  })

  const projects = data?.results || []
  const open = projects.filter(p => p.status === 'open').length
  const inProgress = projects.filter(p => p.status === 'in_progress').length
  const completed = projects.filter(p => p.status === 'completed').length

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="page-title">داشبورد کارفرما</h1>
        <Link to="/employer/projects/create" className="btn-primary gap-2">
          <FiPlusCircle size={16} /> پروژه جدید
        </Link>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard icon={FiBriefcase}   label="کل پروژه‌ها"        value={projects.length} color="blue" />
        <StatCard icon={FiUsers}       label="باز (در انتظار)"    value={open}            color="green" />
        <StatCard icon={FiCheckCircle} label="در حال انجام"       value={inProgress}      color="yellow" />
        <StatCard icon={FiCheckCircle} label="تکمیل شده"          value={completed}       color="purple" />
      </div>

      <div className="card p-5">
        <div className="flex items-center justify-between mb-4">
          <h2 className="section-title">پروژه‌های اخیر</h2>
          <Link to="/employer/projects" className="text-xs text-primary-600 hover:underline">همه</Link>
        </div>
        {isLoading ? <Spinner size="sm" /> : (
          projects.length === 0 ? (
            <div className="text-center py-8">
              <p className="text-gray-400 mb-3">هنوز پروژه‌ای ثبت نکرده‌اید</p>
              <Link to="/employer/projects/create" className="btn-primary text-sm">اولین پروژه را ایجاد کنید</Link>
            </div>
          ) : (
            <ul className="space-y-3">
              {projects.slice(0, 6).map(p => (
                <li key={p.id} className="flex items-center gap-4 py-2 border-b border-gray-50 last:border-0">
                  <div className="flex-1 min-w-0">
                    <p className="font-medium text-gray-800 truncate">{p.title}</p>
                    <p className="text-xs text-gray-400 mt-0.5">{p.proposals_count} پیشنهاد · {p.budget_display}</p>
                  </div>
                  <span className={STATUS_CLS[p.status]}>{STATUS_LBL[p.status]}</span>
                  {p.status === 'open' && (
                    <Link to={`/employer/projects/${p.id}/proposals`} className="btn-secondary text-xs py-1 px-3">
                      بررسی
                    </Link>
                  )}
                </li>
              ))}
            </ul>
          )
        )}
      </div>
    </div>
  )
}

export default EmployerDashboard
