import { useParams } from 'react-router-dom'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { proposalsAPI } from '../../api'
import { Spinner, Empty } from '../../components/common'
import toast from 'react-hot-toast'

export default function ProjectProposals() {
  const { id } = useParams()
  const qc = useQueryClient()

  const { data, isLoading } = useQuery({
    queryKey: ['project-proposals', id],
    queryFn: () => proposalsAPI.projectProposals(id).then(r => r.data.results || []),
  })

  const action = useMutation({
    mutationFn: ({ proposalId, action }) => proposalsAPI.action(proposalId, { action }),
    onSuccess: (_, vars) => {
      toast.success(vars.action === 'accept' ? 'پیشنهاد پذیرفته شد!' : 'پیشنهاد رد شد')
      qc.invalidateQueries(['project-proposals', id])
    },
    onError: (err) => toast.error(err.response?.data?.error?.message || 'خطا'),
  })

  if (isLoading) return <Spinner />

  return (
    <div className="space-y-5">
      <h1 className="page-title">پیشنهادهای دریافتی</h1>
      {!data?.length ? <Empty message="هنوز پیشنهادی دریافت نشده" icon="📬" /> : (
        <div className="space-y-4">
          {data.map(p => (
            <div key={p.id} className="card p-5">
              <div className="flex items-start justify-between gap-4 mb-3">
                <div>
                  <p className="font-semibold text-gray-900">{p.student?.full_name}</p>
                  <p className="text-xs text-gray-500">{p.student?.email}</p>
                </div>
                <div className="text-left">
                  <p className="font-bold text-gray-800">{Number(p.proposed_price).toLocaleString()} تومان</p>
                  <p className="text-xs text-gray-500">{p.proposed_duration_days} روز</p>
                </div>
              </div>
              <p className="text-sm text-gray-600 leading-relaxed mb-4 line-clamp-4">{p.cover_letter}</p>
              {p.status === 'pending' && (
                <div className="flex gap-3">
                  <button
                    onClick={() => action.mutate({ proposalId: p.id, action: 'accept' })}
                    disabled={action.isPending}
                    className="btn-primary text-sm flex-1"
                  >
                    ✓ پذیرش
                  </button>
                  <button
                    onClick={() => action.mutate({ proposalId: p.id, action: 'reject' })}
                    disabled={action.isPending}
                    className="btn-danger text-sm flex-1"
                  >
                    ✕ رد
                  </button>
                </div>
              )}
              {p.status !== 'pending' && (
                <span className={`text-sm font-medium ${p.status === 'accepted' ? 'text-green-600' : 'text-red-500'}`}>
                  {p.status === 'accepted' ? '✓ پذیرفته شده' : '✕ رد شده'}
                </span>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  )
}
