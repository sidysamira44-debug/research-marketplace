import { useState } from 'react'
import { useParams } from 'react-router-dom'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { useForm } from 'react-hook-form'
import { FiClock, FiDollarSign, FiUsers, FiCalendar } from 'react-icons/fi'
import { projectsAPI, proposalsAPI } from '../../api'
import { Spinner } from '../../components/common'
import toast from 'react-hot-toast'

export default function ProjectDetail() {
  const { id } = useParams()
  const [showForm, setShowForm] = useState(false)
  const qc = useQueryClient()

  const { data: project, isLoading } = useQuery({
    queryKey: ['project', id],
    queryFn: () => projectsAPI.detail(id).then(r => r.data.data),
  })

  const { register, handleSubmit, reset, formState: { errors } } = useForm()

  const submitMutation = useMutation({
    mutationFn: (data) => proposalsAPI.submit({ ...data, project_id: id }),
    onSuccess: () => {
      toast.success('پیشنهاد با موفقیت ارسال شد!')
      reset()
      setShowForm(false)
      qc.invalidateQueries(['my-proposals'])
    },
    onError: (err) => {
      toast.error(err.response?.data?.error?.message || 'خطا در ارسال پیشنهاد')
    },
  })

  if (isLoading) return <Spinner />
  if (!project) return <div className="text-center text-gray-400 py-16">پروژه یافت نشد</div>

  return (
    <div className="max-w-3xl space-y-6">
      <div className="card p-6">
        <div className="flex items-start justify-between gap-4 mb-4">
          <div>
            <h1 className="text-xl font-bold text-gray-900">{project.title}</h1>
            <p className="text-sm text-gray-500 mt-1">
              {project.employer?.full_name} · {project.category?.name}
            </p>
          </div>
          {project.is_featured && <span className="badge-yellow flex-shrink-0">⭐ ویژه</span>}
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-5">
          {[
            { icon: FiDollarSign, label: 'بودجه', value: project.budget_display },
            { icon: FiClock, label: 'مدت', value: `${project.duration_days} روز` },
            { icon: FiUsers, label: 'پیشنهادها', value: project.proposals_count },
            { icon: FiCalendar, label: 'مهلت', value: project.deadline || 'نامحدود' },
          ].map(({ icon: Icon, label, value }) => (
            <div key={label} className="bg-gray-50 rounded-lg p-3 text-center">
              <Icon className="mx-auto text-gray-400 mb-1" size={16} />
              <p className="text-xs text-gray-500">{label}</p>
              <p className="text-sm font-semibold text-gray-800">{value}</p>
            </div>
          ))}
        </div>

        {/* Skills */}
        <div className="flex flex-wrap gap-2 mb-5">
          {project.required_skills?.map(s => (
            <span key={s.id} className="bg-primary-50 text-primary-700 text-xs px-3 py-1 rounded-full font-medium">
              {s.name}
            </span>
          ))}
        </div>

        <div className="prose prose-sm max-w-none">
          <h3 className="font-semibold text-gray-800 mb-2">توضیحات</h3>
          <p className="text-gray-600 leading-relaxed whitespace-pre-wrap">{project.description}</p>
          {project.deliverables && (
            <>
              <h3 className="font-semibold text-gray-800 mt-4 mb-2">خروجی‌های مورد انتظار</h3>
              <p className="text-gray-600 whitespace-pre-wrap">{project.deliverables}</p>
            </>
          )}
        </div>

        {project.status === 'open' && (
          <div className="mt-6 border-t border-gray-100 pt-5">
            {!showForm ? (
              <button onClick={() => setShowForm(true)} className="btn-primary w-full py-3">
                ارسال پیشنهاد
              </button>
            ) : (
              <form onSubmit={handleSubmit(d => submitMutation.mutate(d))} className="space-y-4 animate-slide-up">
                <h3 className="font-semibold text-gray-800">ارسال پیشنهاد</h3>

                <div className="grid sm:grid-cols-2 gap-4">
                  <div>
                    <label className="label">قیمت پیشنهادی (تومان)</label>
                    <input {...register('proposed_price', { required: 'الزامی', min: { value: 1, message: 'باید بیشتر از صفر باشد' } })}
                      type="number" className={`input ${errors.proposed_price ? 'input-error' : ''}`} dir="ltr" />
                    {errors.proposed_price && <p className="text-xs text-danger-500 mt-1">{errors.proposed_price.message}</p>}
                  </div>
                  <div>
                    <label className="label">مدت پیشنهادی (روز)</label>
                    <input {...register('proposed_duration_days', { required: 'الزامی', min: { value: 1 } })}
                      type="number" className={`input ${errors.proposed_duration_days ? 'input-error' : ''}`} dir="ltr" />
                  </div>
                </div>

                <div>
                  <label className="label">نامه معرفی</label>
                  <textarea {...register('cover_letter', { required: 'الزامی', minLength: { value: 50, message: 'حداقل ۵۰ کاراکتر' } })}
                    rows={5} placeholder="چرا برای این پروژه مناسب هستید؟ تجربه مرتبط خود را شرح دهید..."
                    className={`input resize-none ${errors.cover_letter ? 'input-error' : ''}`} />
                  {errors.cover_letter && <p className="text-xs text-danger-500 mt-1">{errors.cover_letter.message}</p>}
                </div>

                <div className="flex gap-3">
                  <button type="submit" disabled={submitMutation.isPending} className="btn-primary flex-1">
                    {submitMutation.isPending ? 'در حال ارسال...' : 'ارسال پیشنهاد'}
                  </button>
                  <button type="button" onClick={() => setShowForm(false)} className="btn-secondary">انصراف</button>
                </div>
              </form>
            )}
          </div>
        )}
      </div>
    </div>
  )
}
