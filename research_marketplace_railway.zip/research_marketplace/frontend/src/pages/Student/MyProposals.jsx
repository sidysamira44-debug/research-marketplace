// Student - My Proposals
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { proposalsAPI } from '../../api'
import { Spinner, Empty } from '../../components/common'
import toast from 'react-hot-toast'

const STATUS = {
  pending:   { label: 'در انتظار',     cls: 'badge-yellow' },
  accepted:  { label: 'پذیرفته شده',  cls: 'badge-green'  },
  rejected:  { label: 'رد شده',       cls: 'badge-red'    },
  withdrawn: { label: 'پس گرفته شده', cls: 'badge-gray'   },
}

export default function MyProposals() {
  const qc = useQueryClient()
  const { data, isLoading } = useQuery({
    queryKey: ['my-proposals'],
    queryFn: () => proposalsAPI.myProposals().then(r => r.data.results || []),
  })

  const withdraw = useMutation({
    mutationFn: (id) => proposalsAPI.withdraw(id),
    onSuccess: () => { toast.success('پیشنهاد پس گرفته شد'); qc.invalidateQueries(['my-proposals']) },
    onError: (err) => toast.error(err.response?.data?.error?.message || 'خطا'),
  })

  if (isLoading) return <Spinner />

  return (
    <div className="space-y-5">
      <h1 className="page-title">پیشنهادهای من</h1>
      {!data?.length ? <Empty message="هنوز پیشنهادی ارسال نکرده‌اید" icon="📋" /> : (
        <div className="space-y-3">
          {data.map(p => (
            <div key={p.id} className="card p-5 flex items-center gap-4">
              <div className="flex-1 min-w-0">
                <p className="font-semibold text-gray-900">{typeof p.project === 'string' ? p.project : p.project?.title}</p>
                <p className="text-sm text-gray-500 mt-0.5">
                  قیمت: {Number(p.proposed_price).toLocaleString()} تومان · {p.proposed_duration_days} روز
                </p>
              </div>
              <span className={STATUS[p.status]?.cls || 'badge-gray'}>{STATUS[p.status]?.label}</span>
              {p.status === 'pending' && (
                <button
                  onClick={() => withdraw.mutate(p.id)}
                  disabled={withdraw.isPending}
                  className="btn-secondary text-xs py-1.5 px-3"
                >
                  پس گرفتن
                </button>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  )
}
