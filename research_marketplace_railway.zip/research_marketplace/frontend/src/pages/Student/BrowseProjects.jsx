import { useState } from 'react'
import { useQuery } from '@tanstack/react-query'
import { Link } from 'react-router-dom'
import { FiSearch, FiFilter } from 'react-icons/fi'
import { projectsAPI } from '../../api'
import { Spinner, Empty } from '../../components/common'

const LEVEL_BADGE = {
  beginner: 'badge-green', intermediate: 'badge-blue',
  advanced: 'badge-yellow', expert: 'badge-red',
}
const LEVEL_LABEL = {
  beginner: 'مبتدی', intermediate: 'متوسط', advanced: 'پیشرفته', expert: 'متخصص',
}

export default function BrowseProjects() {
  const [search, setSearch] = useState('')
  const [filters, setFilters] = useState({ experience_level: '', ordering: '-created_at' })
  const [page, setPage] = useState(1)

  const { data, isLoading } = useQuery({
    queryKey: ['projects', search, filters, page],
    queryFn: () => projectsAPI.list({
      search, page, page_size: 12,
      ...Object.fromEntries(Object.entries(filters).filter(([, v]) => v)),
    }).then(r => r.data),
    keepPreviousData: true,
  })

  return (
    <div className="space-y-5">
      <div>
        <h1 className="page-title">پروژه‌های پژوهشی</h1>
        <p className="text-gray-500 text-sm mt-1">{data?.count || 0} پروژه فعال</p>
      </div>

      {/* Search & Filter Bar */}
      <div className="card p-4 flex flex-wrap gap-3">
        <div className="relative flex-1 min-w-48">
          <FiSearch className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400" size={16} />
          <input
            value={search}
            onChange={e => { setSearch(e.target.value); setPage(1) }}
            placeholder="جستجو در پروژه‌ها..."
            className="input pr-9"
          />
        </div>
        <select
          value={filters.experience_level}
          onChange={e => setFilters(f => ({ ...f, experience_level: e.target.value }))}
          className="input w-40"
        >
          <option value="">همه سطوح</option>
          <option value="beginner">مبتدی</option>
          <option value="intermediate">متوسط</option>
          <option value="advanced">پیشرفته</option>
          <option value="expert">متخصص</option>
        </select>
        <select
          value={filters.ordering}
          onChange={e => setFilters(f => ({ ...f, ordering: e.target.value }))}
          className="input w-40"
        >
          <option value="-created_at">جدیدترین</option>
          <option value="budget_min">کمترین بودجه</option>
          <option value="-budget_max">بیشترین بودجه</option>
          <option value="-proposals_count">بیشترین پیشنهاد</option>
        </select>
      </div>

      {/* Project Grid */}
      {isLoading ? <Spinner /> : (
        !data?.results?.length ? <Empty message="پروژه‌ای یافت نشد" icon="🔍" /> : (
          <div className="grid md:grid-cols-2 xl:grid-cols-3 gap-4">
            {data.results.map(project => (
              <Link key={project.id} to={`/student/projects/${project.id}`}
                className="card p-5 hover:shadow-md transition-shadow group"
              >
                {project.is_featured && (
                  <span className="badge-yellow text-xs mb-2 inline-block">⭐ ویژه</span>
                )}
                <h3 className="font-semibold text-gray-900 group-hover:text-primary-600 transition-colors line-clamp-2 mb-2">
                  {project.title}
                </h3>
                <div className="flex items-center gap-2 mb-3">
                  <span className={LEVEL_BADGE[project.experience_level]}>
                    {LEVEL_LABEL[project.experience_level]}
                  </span>
                  {project.category && (
                    <span className="badge-gray">{project.category.name}</span>
                  )}
                </div>
                <div className="flex flex-wrap gap-1 mb-3">
                  {project.required_skills?.slice(0, 3).map(s => (
                    <span key={s.id} className="text-xs bg-gray-100 text-gray-600 px-2 py-0.5 rounded-full">{s.name}</span>
                  ))}
                  {project.required_skills?.length > 3 && (
                    <span className="text-xs text-gray-400">+{project.required_skills.length - 3}</span>
                  )}
                </div>
                <div className="flex items-center justify-between text-xs text-gray-500 border-t border-gray-100 pt-3 mt-auto">
                  <span className="font-medium text-gray-700">{project.budget_display}</span>
                  <span>{project.proposals_count} پیشنهاد</span>
                </div>
              </Link>
            ))}
          </div>
        )
      )}

      {/* Pagination */}
      {data?.total_pages > 1 && (
        <div className="flex items-center justify-center gap-2">
          <button onClick={() => setPage(p => Math.max(1, p - 1))} disabled={page === 1} className="btn-secondary px-3 py-1.5 text-sm">قبلی</button>
          <span className="text-sm text-gray-600">صفحه {page} از {data.total_pages}</span>
          <button onClick={() => setPage(p => Math.min(data.total_pages, p + 1))} disabled={page === data.total_pages} className="btn-secondary px-3 py-1.5 text-sm">بعدی</button>
        </div>
      )}
    </div>
  )
}
