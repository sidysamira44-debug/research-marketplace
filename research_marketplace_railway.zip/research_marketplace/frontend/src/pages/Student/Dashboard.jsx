import { useQuery } from '@tanstack/react-query'
import { Link } from 'react-router-dom'
import { FiBriefcase, FiFileText, FiStar, FiClock } from 'react-icons/fi'
import { projectsAPI, proposalsAPI } from '../../api'
import useAuthStore from '../../store/authStore'
import StatCard from '../../components/common/StatCard'
import { Spinner } from '../../components/common'

const STATUS_BADGE = {
  pending:   'badge-yellow',
  accepted:  'badge-green',
  rejected:  'badge-red',
  withdrawn: 'badge-gray',
}
const STATUS_LABEL = {
  pending: 'در انتظار', accepted: 'پذیرفته', rejected: 'رد شده', withdrawn: 'پس گرفته',
}

export default function StudentDashboard() {
  const { user } = useAuthStore()

  const { data: proposals, isLoading } = useQuery({
    queryKey: ['my-proposals'],
    queryFn: () => proposalsAPI.myProposals().then(r => r.data.results || []),
  })

  const { data: openProjects } = useQuery({
    queryKey: ['open-projects', { page_size: 4 }],
    queryFn: () => projectsAPI.list({ page_size: 4 }).then(r => r.data.results || []),
  })

  const accepted = proposals?.filter(p => p.status === 'accepted').length || 0
  const pending  = proposals?.filter(p => p.status === 'pending').length  || 0

  return (
    <div className="space-y-6">
      {/* Welcome */}
      <div>
        <h1 className="page-title">سلام، {user?.full_name} 👋</h1>
        <p className="text-gray-500 text-sm mt-1">وضعیت فعالیت‌های شما</p>
      </div>

      {!user?.is_verified && (
        <div className="bg-yellow-50 border border-yellow-200 rounded-xl p-4 flex items-start gap-3">
          <span className="text-2xl">⏳</span>
          <div>
            <p className="font-semibold text-yellow-800 text-sm">حساب در انتظار تأیید</p>
            <p className="text-yellow-700 text-xs mt-0.5">پس از تأیید توسط مدیریت، می‌توانید پیشنهاد ارسال کنید.</p>
          </div>
        </div>
      )}

      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard icon={FiFileText} label="کل پیشنهادها" value={proposals?.length} color="blue" />
        <StatCard icon={FiStar}     label="پذیرفته شده"  value={accepted}           color="green" />
        <StatCard icon={FiClock}    label="در انتظار"    value={pending}            color="yellow" />
        <StatCard icon={FiBriefcase} label="پروژه‌های باز" value={openProjects?.length} color="purple" />
      </div>

      <div className="grid lg:grid-cols-2 gap-6">
        {/* Recent proposals */}
        <div className="card p-5">
          <div className="flex items-center justify-between mb-4">
            <h2 className="section-title">آخرین پیشنهادها</h2>
            <Link to="/student/proposals" className="text-xs text-primary-600 hover:underline">همه</Link>
          </div>
          {isLoading ? <Spinner size="sm" /> : (
            proposals?.length === 0 ? (
              <p className="text-sm text-gray-400 text-center py-6">هنوز پیشنهادی ارسال نکرده‌اید</p>
            ) : (
              <ul className="space-y-3">
                {proposals?.slice(0, 4).map(p => (
                  <li key={p.id} className="flex items-center justify-between py-2 border-b border-gray-50 last:border-0">
                    <div className="min-w-0">
                      <p className="text-sm font-medium text-gray-800 truncate">{p.project}</p>
                      <p className="text-xs text-gray-400">{p.proposed_price?.toLocaleString()} تومان</p>
                    </div>
                    <span className={STATUS_BADGE[p.status] || 'badge-gray'}>
                      {STATUS_LABEL[p.status]}
                    </span>
                  </li>
                ))}
              </ul>
            )
          )}
        </div>

        {/* Open projects */}
        <div className="card p-5">
          <div className="flex items-center justify-between mb-4">
            <h2 className="section-title">پروژه‌های جدید</h2>
            <Link to="/student/projects" className="text-xs text-primary-600 hover:underline">همه</Link>
          </div>
          <ul className="space-y-3">
            {openProjects?.map(p => (
              <li key={p.id}>
                <Link to={`/student/projects/${p.id}`} className="flex items-center justify-between py-2 border-b border-gray-50 last:border-0 hover:bg-gray-50 rounded px-2 -mx-2 transition">
                  <div className="min-w-0">
                    <p className="text-sm font-medium text-gray-800 truncate">{p.title}</p>
                    <p className="text-xs text-gray-400">{p.budget_display}</p>
                  </div>
                  <span className="badge-blue text-xs">{p.proposals_count} پیشنهاد</span>
                </Link>
              </li>
            ))}
          </ul>
        </div>
      </div>
    </div>
  )
}
