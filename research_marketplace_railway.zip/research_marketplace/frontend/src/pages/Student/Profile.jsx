import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { useForm } from 'react-hook-form'
import { useEffect } from 'react'
import { profilesAPI } from '../../api'
import { Spinner } from '../../components/common'
import toast from 'react-hot-toast'

export default function StudentProfile() {
  const qc = useQueryClient()
  const { data: profile, isLoading } = useQuery({
    queryKey: ['my-student-profile'],
    queryFn: () => profilesAPI.myStudent().then(r => r.data.data),
  })

  const { register, handleSubmit, reset, formState: { errors } } = useForm()
  useEffect(() => { if (profile) reset(profile) }, [profile, reset])

  const update = useMutation({
    mutationFn: (data) => profilesAPI.updateStudent(data),
    onSuccess: () => { toast.success('پروفایل به‌روزرسانی شد'); qc.invalidateQueries(['my-student-profile']) },
    onError: () => toast.error('خطا در ذخیره'),
  })

  if (isLoading) return <Spinner />

  return (
    <div className="max-w-2xl space-y-6">
      <h1 className="page-title">پروفایل دانشجو</h1>
      <form onSubmit={handleSubmit(d => update.mutate(d))} className="card p-6 space-y-4">
        <div className="grid sm:grid-cols-2 gap-4">
          <div>
            <label className="label">دانشگاه</label>
            <input {...register('university')} className="input" placeholder="دانشگاه تهران" />
          </div>
          <div>
            <label className="label">رشته تحصیلی</label>
            <input {...register('field_of_study')} className="input" placeholder="بیوانفورماتیک" />
          </div>
          <div>
            <label className="label">مقطع</label>
            <select {...register('degree')} className="input">
              <option value="">انتخاب کنید</option>
              <option value="bachelor">کارشناسی</option>
              <option value="master">کارشناسی ارشد</option>
              <option value="phd">دکترا</option>
              <option value="postdoc">پست دکترا</option>
            </select>
          </div>
          <div>
            <label className="label">معدل</label>
            <input {...register('gpa')} type="number" step="0.01" min="0" max="20" className="input" dir="ltr" />
          </div>
          <div>
            <label className="label">وضعیت پذیرش</label>
            <select {...register('availability')} className="input">
              <option value="available">آماده همکاری</option>
              <option value="part_time">پاره وقت</option>
              <option value="busy">مشغول</option>
            </select>
          </div>
          <div>
            <label className="label">نرخ ساعتی (تومان)</label>
            <input {...register('hourly_rate')} type="number" className="input" dir="ltr" />
          </div>
        </div>
        <div>
          <label className="label">درباره من</label>
          <textarea {...register('bio')} rows={4} className="input resize-none" placeholder="خودتان را معرفی کنید..." />
        </div>
        <div>
          <label className="label">حوزه‌های پژوهشی</label>
          <textarea {...register('research_interests')} rows={3} className="input resize-none" placeholder="علاقه‌مندی‌های پژوهشی..." />
        </div>
        <div className="grid sm:grid-cols-2 gap-4">
          <div>
            <label className="label">گیت‌هاب</label>
            <input {...register('github_url')} className="input" placeholder="https://github.com/..." dir="ltr" />
          </div>
          <div>
            <label className="label">لینکدین</label>
            <input {...register('linkedin_url')} className="input" placeholder="https://linkedin.com/in/..." dir="ltr" />
          </div>
        </div>
        <button type="submit" disabled={update.isPending} className="btn-primary w-full py-2.5">
          {update.isPending ? 'در حال ذخیره...' : 'ذخیره تغییرات'}
        </button>
      </form>
    </div>
  )
}
