import { Outlet, NavLink, useNavigate } from 'react-router-dom'
import { useState } from 'react'
import {
  FiHome, FiUser, FiBriefcase, FiFileText, FiLogOut,
  FiBell, FiMenu, FiX, FiUsers, FiAlertTriangle,
  FiPlusCircle, FiSearch,
} from 'react-icons/fi'
import useAuthStore from '../../store/authStore'
import { useQuery } from '@tanstack/react-query'
import { notificationsAPI } from '../../api'
import toast from 'react-hot-toast'

const NAV = {
  student: [
    { to: '/student',          icon: FiHome,       label: 'داشبورد' },
    { to: '/student/projects', icon: FiSearch,     label: 'پروژه‌ها' },
    { to: '/student/proposals',icon: FiFileText,   label: 'پیشنهادهای من' },
    { to: '/student/profile',  icon: FiUser,       label: 'پروفایل' },
  ],
  employer: [
    { to: '/employer',                    icon: FiHome,       label: 'داشبورد' },
    { to: '/employer/projects',           icon: FiBriefcase,  label: 'پروژه‌های من' },
    { to: '/employer/projects/create',    icon: FiPlusCircle, label: 'پروژه جدید' },
    { to: '/employer/profile',            icon: FiUser,       label: 'پروفایل' },
  ],
  admin: [
    { to: '/admin',          icon: FiHome,         label: 'داشبورد' },
    { to: '/admin/users',    icon: FiUsers,        label: 'کاربران' },
    { to: '/admin/disputes', icon: FiAlertTriangle,label: 'اختلافات' },
  ],
}

const ROLE_LABEL = { student: 'دانشجو', employer: 'کارفرما', admin: 'مدیر' }

export default function DashboardLayout({ role }) {
  const { user, logout } = useAuthStore()
  const navigate = useNavigate()
  const [sidebarOpen, setSidebarOpen] = useState(true)

  const { data: unread } = useQuery({
    queryKey: ['unread-count'],
    queryFn: () => notificationsAPI.unreadCount().then(r => r.data.data.unread_count),
    refetchInterval: 30000,
  })

  const handleLogout = async () => {
    await logout()
    toast.success('با موفقیت خارج شدید')
    navigate('/login')
  }

  return (
    <div className="flex h-screen bg-gray-50 overflow-hidden">
      {/* Sidebar */}
      <aside className={`${sidebarOpen ? 'w-60' : 'w-16'} bg-white border-l border-gray-200 flex flex-col transition-all duration-300 flex-shrink-0`}>
        {/* Header */}
        <div className="flex items-center gap-3 px-4 py-4 border-b border-gray-100">
          <div className="w-8 h-8 bg-primary-600 rounded-lg flex items-center justify-center flex-shrink-0">
            <span className="text-white text-sm font-bold">پ</span>
          </div>
          {sidebarOpen && (
            <div className="min-w-0">
              <p className="text-sm font-semibold text-gray-900 truncate">{user?.full_name}</p>
              <p className="text-xs text-gray-500">{ROLE_LABEL[role]}</p>
            </div>
          )}
        </div>

        {/* Nav */}
        <nav className="flex-1 px-2 py-4 space-y-1 overflow-y-auto">
          {NAV[role]?.map(({ to, icon: Icon, label }) => (
            <NavLink
              key={to}
              to={to}
              end={to === `/${role}`}
              className={({ isActive }) =>
                `sidebar-link ${isActive ? 'active' : ''}`
              }
            >
              <Icon size={18} className="flex-shrink-0" />
              {sidebarOpen && <span>{label}</span>}
            </NavLink>
          ))}
        </nav>

        {/* Footer */}
        <div className="px-2 py-4 border-t border-gray-100 space-y-1">
          {!user?.is_verified && sidebarOpen && (
            <div className="mx-2 mb-2 px-3 py-2 bg-yellow-50 border border-yellow-200 rounded-lg">
              <p className="text-xs text-yellow-700">⏳ حساب شما در انتظار تأیید است</p>
            </div>
          )}
          <button
            onClick={handleLogout}
            className="sidebar-link w-full text-danger-500 hover:bg-red-50 hover:text-danger-600"
          >
            <FiLogOut size={18} className="flex-shrink-0" />
            {sidebarOpen && <span>خروج</span>}
          </button>
        </div>
      </aside>

      {/* Main */}
      <div className="flex-1 flex flex-col min-w-0">
        {/* Top bar */}
        <header className="bg-white border-b border-gray-200 px-6 py-3 flex items-center justify-between flex-shrink-0">
          <button
            onClick={() => setSidebarOpen(o => !o)}
            className="btn-ghost p-2 rounded-lg"
          >
            {sidebarOpen ? <FiX size={20} /> : <FiMenu size={20} />}
          </button>

          {/* Notifications bell */}
          <button
            className="relative btn-ghost p-2 rounded-lg"
            onClick={() => navigate(`/${role}/notifications`)}
          >
            <FiBell size={20} />
            {unread > 0 && (
              <span className="absolute -top-0.5 -right-0.5 bg-danger-500 text-white text-xs w-4 h-4 rounded-full flex items-center justify-center">
                {unread > 9 ? '۹+' : unread}
              </span>
            )}
          </button>
        </header>

        {/* Page content */}
        <main className="flex-1 overflow-y-auto p-6">
          <div className="max-w-6xl mx-auto animate-fade-in">
            <Outlet />
          </div>
        </main>
      </div>
    </div>
  )
}
