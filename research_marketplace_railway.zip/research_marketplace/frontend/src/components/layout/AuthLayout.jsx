import { Outlet, Navigate } from 'react-router-dom'
import useAuthStore from '../../store/authStore'

const ROLE_HOME = { student: '/student', employer: '/employer', admin: '/admin' }

export default function AuthLayout() {
  const { isAuthenticated, user } = useAuthStore()

  if (isAuthenticated && user) {
    return <Navigate to={ROLE_HOME[user.role] || '/student'} replace />
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary-50 via-white to-blue-50 flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        {/* Logo */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-14 h-14 bg-primary-600 rounded-2xl shadow-lg mb-4">
            <span className="text-white text-2xl font-bold">پ</span>
          </div>
          <h1 className="text-2xl font-bold text-gray-900">پلتفرم پژوهشی</h1>
          <p className="text-sm text-gray-500 mt-1">اتصال دانشجویان به فرصت‌های پژوهشی</p>
        </div>
        <div className="card p-8 shadow-lg animate-slide-up">
          <Outlet />
        </div>
      </div>
    </div>
  )
}
