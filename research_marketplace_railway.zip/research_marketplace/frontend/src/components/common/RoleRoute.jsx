import { Navigate } from 'react-router-dom'
import useAuthStore from '../../store/authStore'

const ROLE_HOME = { student: '/student', employer: '/employer', admin: '/admin' }

export default function RoleRoute({ role, children }) {
  const { user } = useAuthStore()
  if (!user) return null
  if (user.role !== role) {
    return <Navigate to={ROLE_HOME[user.role] || '/login'} replace />
  }
  return children
}
