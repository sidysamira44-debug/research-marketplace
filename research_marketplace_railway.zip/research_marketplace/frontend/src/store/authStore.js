import { create } from 'zustand'
import { persist } from 'zustand/middleware'
import { authAPI } from '../api'

const useAuthStore = create(
  persist(
    (set, get) => ({
      user: null,
      accessToken: null,
      refreshToken: null,
      isAuthenticated: false,

      setTokens: (access, refresh) => {
        localStorage.setItem('access_token', access)
        localStorage.setItem('refresh_token', refresh)
        set({ accessToken: access, refreshToken: refresh, isAuthenticated: true })
      },

      setUser: (user) => set({ user }),

      login: async (email, password) => {
        const { data } = await authAPI.login({ email, password })
        const { user, tokens } = data.data
        get().setTokens(tokens.access, tokens.refresh)
        set({ user, isAuthenticated: true })
        return user
      },

      logout: async () => {
        try {
          const refresh = localStorage.getItem('refresh_token')
          if (refresh) await authAPI.logout(refresh)
        } catch (_) {}
        localStorage.removeItem('access_token')
        localStorage.removeItem('refresh_token')
        set({ user: null, accessToken: null, refreshToken: null, isAuthenticated: false })
      },

      fetchMe: async () => {
        const { data } = await authAPI.me()
        set({ user: data.data })
        return data.data
      },

      updateUser: (partial) => set((state) => ({ user: { ...state.user, ...partial } })),
    }),
    {
      name: 'auth-storage',
      partialize: (state) => ({
        user: state.user,
        accessToken: state.accessToken,
        refreshToken: state.refreshToken,
        isAuthenticated: state.isAuthenticated,
      }),
    }
  )
)

export default useAuthStore
