import { createBrowserRouter } from 'react-router-dom'

// Layouts
import AuthLayout from '../components/layout/AuthLayout'
import DashboardLayout from '../components/layout/DashboardLayout'

// Auth Pages
import LoginPage from '../pages/Auth/LoginPage'
import RegisterPage from '../pages/Auth/RegisterPage'

// Student Pages
import StudentDashboard from '../pages/Student/Dashboard'
import StudentProfile from '../pages/Student/Profile'
import BrowseProjects from '../pages/Student/BrowseProjects'
import ProjectDetail from '../pages/Student/ProjectDetail'
import MyProposals from '../pages/Student/MyProposals'

// Employer Pages
import EmployerDashboard from '../pages/Employer/Dashboard'
import EmployerProfile from '../pages/Employer/Profile'
import MyProjects from '../pages/Employer/MyProjects'
import CreateProject from '../pages/Employer/CreateProject'
import ProjectProposals from '../pages/Employer/ProjectProposals'

// Admin Pages
import AdminDashboard from '../pages/Admin/Dashboard'
import AdminUsers from '../pages/Admin/Users'
import AdminDisputes from '../pages/Admin/Disputes'

// Guards
import ProtectedRoute from '../components/common/ProtectedRoute'
import RoleRoute from '../components/common/RoleRoute'

const router = createBrowserRouter([
  // ── Public Auth Routes ──
  {
    element: <AuthLayout />,
    children: [
      { path: '/login',    element: <LoginPage /> },
      { path: '/register', element: <RegisterPage /> },
    ],
  },

  // ── Student Routes ──
  {
    element: (
      <ProtectedRoute>
        <RoleRoute role="student">
          <DashboardLayout role="student" />
        </RoleRoute>
      </ProtectedRoute>
    ),
    children: [
      { path: '/student',                     element: <StudentDashboard /> },
      { path: '/student/profile',             element: <StudentProfile /> },
      { path: '/student/projects',            element: <BrowseProjects /> },
      { path: '/student/projects/:id',        element: <ProjectDetail /> },
      { path: '/student/proposals',           element: <MyProposals /> },
    ],
  },

  // ── Employer Routes ──
  {
    element: (
      <ProtectedRoute>
        <RoleRoute role="employer">
          <DashboardLayout role="employer" />
        </RoleRoute>
      </ProtectedRoute>
    ),
    children: [
      { path: '/employer',                      element: <EmployerDashboard /> },
      { path: '/employer/profile',              element: <EmployerProfile /> },
      { path: '/employer/projects',             element: <MyProjects /> },
      { path: '/employer/projects/create',      element: <CreateProject /> },
      { path: '/employer/projects/:id/proposals', element: <ProjectProposals /> },
    ],
  },

  // ── Admin Routes ──
  {
    element: (
      <ProtectedRoute>
        <RoleRoute role="admin">
          <DashboardLayout role="admin" />
        </RoleRoute>
      </ProtectedRoute>
    ),
    children: [
      { path: '/admin',           element: <AdminDashboard /> },
      { path: '/admin/users',     element: <AdminUsers /> },
      { path: '/admin/disputes',  element: <AdminDisputes /> },
    ],
  },

  // ── Root redirect ──
  { path: '/', element: <LoginPage /> },
  { path: '*', element: <div className="flex items-center justify-center h-screen text-gray-500">صفحه یافت نشد</div> },
])

export default router
