"""ASGI config — supports both HTTP and WebSocket (Phase 4 Channels)."""
import os
from django.core.asgi import get_asgi_application

os.environ.setdefault("DJANGO_SETTINGS_MODULE", "config.settings.prod")
application = get_asgi_application()
